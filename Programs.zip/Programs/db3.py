
import pymysql

try:
    #step1
    with pymysql.connect(host='127.0.0.1',port=3306,user='root',password='giri@123',database='dellemc') as conn:
        cursor = conn.cursor()
        #step2
        query = "insert into adultinfo values('{}','{}','{}')".format('public','doctor','mbbs')
        #step3
        cursor.execute(query)
        #step4
        print(cursor.rowcount,"record inserted")
        # make the changesr permanent
        conn.commit()

    
except Exception as err:
    print(err)
    
    