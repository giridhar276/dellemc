data = { 
  "name"   : "John Smith",
  "sku"    : "20223",
  "price"  : 23.95,
  "shipTo" : { "name" : "Jane Smith",
               "address" : "123 Maple Street",
               "city" : "Pretendville",
               "state" : "NY",
               "zip"   : "12345" },
  "billTo" : { "name" : "John Smith",
               "address" : "123 Maple Street",
               "city" : "Pretendville",
               "state" : "NY",
               "zip"   : "12345" }
}

for key,value in data.items():
    if isinstance(value,str):
        print(key.ljust(10),":",value)
    elif isinstance(value,dict):
        for key,value in value.items():
            print(key.ljust(10),":",value)

