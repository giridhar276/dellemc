
# list

alist = [10,20,30,40]
alist[0] = 100
print(alist)


## elements inside tuple cannot be modified directly
atup = (10,20,30,40)
atup[0] = 100    # error
print(atup)

# typecasting - converting from one object to another object
atup = (10,20,30,40)
alist = list(atup)   # convetting to list
alist.append(50)     # making changes
atup = tuple(alist)  # converting back to tuple
print(atup)          # dipslaying output

