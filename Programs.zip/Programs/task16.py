

import os
try:
    for val in range(1,10):
        dirname = "dir" + str(val)
        if not os.path.isdir(dirname):
            os.mkdir(dirname)
            print(dirname,"created")
        else:
            print(dirname,"already exists")
except Exception as err:
    print(err)    