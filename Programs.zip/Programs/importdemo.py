# method1 : all the methods are imported to your space
import math
print(math.log(2))
print(math.cos(1))

# method2 : importing with alias
import matplotlib.pyplot as plt
plt.plot([10,20],[30,40])


# method3  # . is not required in this context
from math import floor,cos,log
print(floor(1.3))
print(cos(2))