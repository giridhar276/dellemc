

import shutil
import os
try:
    source = r'C:\Users\Administrator\Desktop\Programs\source'
    destination = r'C:\Users\Administrator\Desktop\Programs\destination'
    for file in os.listdir(source):
        shutil.copy(source + "\\" + file , destination)
        print(file,"copied from ",source,"to",destination)
    
except Exception as err:
    print(err)