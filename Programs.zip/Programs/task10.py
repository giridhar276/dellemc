lang  = ["spark","spark","spark","java","unix","unix","python","python"]


for val in set(lang):
    print(val.ljust(10),lang.count(val),"times")