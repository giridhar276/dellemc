# tradional way
def display(a,b):
    c  = a + b
    return c
total  = display(10,20)
print(total)

# pythonic way
#lambda function
#syntax:
#functioname = lambda variables:expression

display = lambda x,y:x+y
total  = display(10,20)
print(total)

square = lambda x : x * x if x > 0 else 'not possible'
total = square(2)
print(total)
total = square(0)
print(total)

sumofvalues = lambda *args : sum(args)
total = sumofvalues(10,20,30,40,50,30,20,43,30,320,32)
print(total)




alist = ["google",'unix',"oracle"]
#["www.google.com","www.unix".com","www.oracle.com"]
# 1st method
blist = []
for val in alist:
    blist.append("www." + val + ".com")
print(blist)

# 2nd method list comprehension
# syntax  [expression  forloop]
output = [  "www." + val + ".com"    for val in alist]
print(output)

#map(function,iterable)
def concat(x):
    return "www." + x + ".com"
print(list(map(concat,alist)))



concat = lambda x : "www." + x + ".com"
print(list(map(concat,alist)))


print(list(map( lambda x : "www." + x + ".com",alist)))



alist = ['1','2','3','4']
#[1,2,3,4]
print(list(map(int,alist)))


convert = lambda x : int(x)
print(list(map(convert,alist)))

print(list(map(lambda x : int(x),alist)))


alist = ["unix","java","oracle","python",'perl']
#["unix","java",'perl']
check = lambda x: len(x) == 4
print(list(filter(check,alist)))



print(list(filter(lambda x: len(x) == 4,alist)))








