alist = [10,45,23,67,32,1,45,34,10,10,10]

getcount = alist.count(alist)
print(getcount)

alist.append(43)  # adding element to the end of the list
print('After appending :',alist)
alist.extend([49,93,23])
print('After extending :',alist)
alist.insert(1,15)
print('AFter inserting :',alist)

alist.pop(4)  # list.pop(index)
print('After pop:',alist)
alist.pop()   # last element will be removed
print('After pop :',alist)
#list.remove(value)
alist.remove(10000)  #
print(alist)

if 10000 in alist:
    alist.remove(100)
    print(alist)
else:
    print(100,"not in the list")

alist.sort()
print('After sorting :',alist)

alist.reverse()
print('After reversing',alist)

if 200 in alist:
    print("value exists")
else:
    print('value doesnt exist')


getcount = alist.count(200)
if getcount != 0:
    print("value exists")

# for loop
for val in alist:
    print(val)
    
    
    
    
    

