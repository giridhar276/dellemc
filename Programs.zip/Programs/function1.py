# fixed arguments
def display(a,b):
    c  = a + b
    return c
total  = display(10,20)
print(total)

# default arguments
def display(a = None,b = None,c = None):
    print(a,b,c)
display()
display(10)
display(10,20)
display(10,20,30)


# keyword arguments
def display(c,a,b):
    print(a,b,c)
    
display(b=20,a=10,c=30)

# variable length arguments


def display(*args):
    for val in args:
        print(val)

display(10,20,30,40,50,56,34,3,45,43)















