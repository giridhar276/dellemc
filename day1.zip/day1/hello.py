print(10,20,30)
print("unix","java")

name = 'python'
print("I love",name)

# this is single line comment

'''
print("unix","java")
name = 'python'
print("I love",name)

'''