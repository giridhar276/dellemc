
aset = {10,10,20,30,30,30}
aset.add(30)
aset.add(40)
print(aset)

bset = {30,30,40,40,50}

print(aset.union(bset))

print(aset.intersection(bset))

print(aset.difference(bset))

print(bset.difference(aset))

print(aset.issubset(bset))

