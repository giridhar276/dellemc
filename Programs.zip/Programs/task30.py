

# web scraping
import requests    # read the webpage html/json
from bs4 import BeautifulSoup  # extract data from html/xml

# just like select query
response = requests.get('https://www.google.com/')

if response.status_code == 200:
    soup = BeautifulSoup(response.text, 'html.parser')
    for link in soup.find_all('a'):
        print(link.get('href'))
        print("---------")