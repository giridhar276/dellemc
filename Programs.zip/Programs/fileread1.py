# readin the file line by line

# fobj acts like the cursor
with open('adult.csv','r') as fobj:
    for line in fobj:
        print(line.strip())
        
       
# using csv library
import csv
with open('adult.csv','r') as fobj:
    # converting file object to csv  object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)
        
