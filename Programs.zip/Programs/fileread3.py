# using csv library
import csv
workset = set()
with open('adult.csv','r') as fobj:
    # converting file object to csv  object
    reader = csv.reader(fobj)
    # procesing
    for line in reader:
        workclass = line[1]
        workset.add(workclass)
    # display output
    for work in workset:
        print(work)        





import csv
workdict = dict()
with open('adult.csv','r') as fobj:
    # converting file object to csv  object
    reader = csv.reader(fobj)
    # procesing
    for line in reader:
        workclass = line[1]
        #{'Private':1 ,'Public':1}
        workdict[workclass] = 1
    # display output
    for work in workdict:
        print(work)        





workdict = dict()
with open('adult.csv','r') as fobj:
    # converting file object to csv  object
    reader = csv.reader(fobj)
    # procesing
    for line in reader:
        workclass = line[1]
        workdict[workclass] = 1
    # display output
    for work in workdict:
        print(work)        
