
import pymysql

try:
    #step1
    with pymysql.connect(host='127.0.0.1',port=3306,user='root',password='giri@123') as conn:
        cursor = conn.cursor()
        #step2
        query = "select * from dellemc.adultinfo"
        #step3
        cursor.execute(query)
        #step4
        for record in cursor.fetchall():
            print(record[0])
            print(record[1])
            print(record[2])
        #step5
    
except Exception as err:
    print(err)
    
    