

import re  # linux     grep + awk + sed
# ^ - searching at the beginning of hte string
with open('languages.txt') as fobj:
    for line in fobj:
        if re.search('^python',line):
            print(line.strip())


# $ - all the lines ending with string
with open('languages.txt') as fobj:
    for line in fobj:
        if re.search('python$',line):
            print(line.strip())


#  * - zero of more occurences of the preceding character
with open('languages.txt') as fobj:
    for line in fobj:
        if re.search('pyt*hon',line):
            print(line.strip())
            
            
#  + - one or more occurences of the preceding character
with open('languages.txt') as fobj:
    for line in fobj:
        if re.search('pyt+hon',line):
            print(line.strip())
            
            
#  ? - zero or one occurence of the preceding character
with open('languages.txt') as fobj:
    for line in fobj:
        if re.search('pyt?hon',line):
            print(line.strip())
            
            
            
#  (pattern1|pattern2) either first or second
with open('languages.txt') as fobj:
    for line in fobj:
        if re.search('python|unix',line):
            print(line.strip())
            
            
# . - any single character     
with open('languages.txt') as fobj:
    for line in fobj:
        if re.search('.ython',line):
            print(line.strip())          
            
            
# [qwrt] either q or w or r or t           
with open('languages.txt') as fobj:
    for line in fobj:
        # either qython or wython or rython or tython
        if re.search('[qwrt]ython',line):
            print(line.strip())          
                        
#{ min,max}  min to max occurences of preceding
with open('languages.txt') as fobj:
    for line in fobj:
        # either qython or wython or rython or tython
        if re.search('pyt{2,5}hon',line):
            print(line.strip())          





            
            