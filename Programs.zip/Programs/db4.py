import pymysql
import os
import csv
try:
    with pymysql.connect(host='127.0.0.1',port=3306,user='root',password='giri@123',database='dellemc') as conn:
        cursor = conn.cursor()
        filename = "adult.csv"
        count = 0
        if os.path.isfile(filename) and os.path.getsize(filename) > 0:
            with open(filename,"r") as fobj:
                reader = csv.reader(fobj)
                for line in reader:
                    workclass = line[1]
                    education = line[3]
                    occupation = line[6]
                    query = "insert into adultinfo values('{}','{}','{}')".format(workclass,education,occupation)
                    cursor.execute(query)
                    count = count + 1
        
                print(count,"records inserted")
        conn.commit()
except Exception as err:
    print(err)
                    
        
        