# program1
fobj = open('data.txt','w')
fobj.write('python\n')
fobj.write('unix\n')
fobj.close()

# program2
fnum = open('numbers.txt','w')
for val in range(1,11):
    fnum.write(str(val) + "\n")
fnum.close()

#fw = open(r"C:\Users\Administrator\Desktop\newoutput\numbers.txt",'w') # rawstring
#fw = open("C:/Users/Administrator/Desktop/newoutput/numbers.txt",'w')
fw = open("C:\\Users\\Administrator\\Desktop\\newoutput\\numbers.txt",'w')
fw.write('hello\n')
fw.close()


