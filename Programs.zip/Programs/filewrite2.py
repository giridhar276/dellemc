# program1
fobj = open('datainput.txt','w')
fobj.write('python\n')
fobj.write('unix\n')
fobj.close()

# pythonic way
# context manager
# file gets closed automatically when it comes out of indentaiton
with open('datainput.txt','w') as fobj:
    fobj.write('unix shell\n')
    fobj.write('java\n')

    





