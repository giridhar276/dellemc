
import csv
male = 0
female = 0
with open('adult.csv','r') as fobj:
    # converting file object to csv  object
    reader = csv.reader(fobj)
    # procesing
    for line in reader:
        gender = line[9].strip()
        if gender == 'Male':
            male = male + 1
        elif gender == 'Female':
            female = female + 1
    
    print("total male count   :",male)
    print("Total female count :",female)
            