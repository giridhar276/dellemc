# display all the files from current directory
import os 
try:
    files = os.listdir()
    
    for file in files:
        print(file)
except Exception as err:
    print(err)
    
    
# display all the files from C:||
import os 
try:
    files = os.listdir("C:\\")
    
    for file in files:
        print(file)
except Exception as err:
    print(err)