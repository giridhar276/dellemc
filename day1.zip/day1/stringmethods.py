# string[start:stop:step]
# string slicing
name = 'python programming'
print(name[0])
print(name[1])
print(name[0:4])
print(name[4:9])
print(name[0:18])    #python programming
print(name[0:18:1])  #python programming
print(name[0:18:2])
print(name[1:18:2])
print(name[:])
print(name[::])
print(name[-1])  #g
print(name[-2]) #n
print(name[-5:-1])
print(name[::-1])

name = 'python programming'
print(name.capitalize())
print(name.title())
print(name.upper())
print(name.lower())

print(name.isupper())
print(name.islower())
print(name.count('p',4,6))
print(name.center(40))
print(name.center(40,"*"))
print(name.endswith('g'))
print(name.endswith('z'))
print(name.startswith('p'))
print(name.startswith('t'))

aname = "I love {} and {}"
print(aname.format('unix','java'))
print(aname.format('python',345))

bname = "  python "
print(len(bname))
print(len(bname.strip()))
print(len(bname.lstrip()))
print(len(bname.rstrip()))      
print(name.replace('python','java'))
print(name.split(" "))


# simple if
name = 'python'
if name.isupper():
    print('string is upper')
    print('inside if')
    print('still inside if')
# if-else
if name.startswith('p'):
    print('python programming')
else:
    print('some other language')

# if-elif-elif-else
color = input('Enter any color')
if color == 'red':
    print('red color')
elif color == 'green':
    print('green')
elif color =='blue':
    print('blue')
else:
    print('some other color')


# display numbers from 1 to 10
for val in range(1,11):
    print(val)
    
# for loop with string
for char in name:
    print(char)
    
# iterating the list
alist = [10,20,30]
for val in alist:
    print(val)
    
    
    
    
    
    
























