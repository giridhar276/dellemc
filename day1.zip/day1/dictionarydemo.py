
book  = {"chap1":10,"chap2":20 ,"chap3":30,'chap1':100}
print(book)

# display keys
print(book.keys())
# display values
print(book.values())
# display items
print(book.items())

# create new key-value pairs
book['chap4'] = 40
book['chap5'] = 50
print(book)

# display value
print(book['chap1'])
print(book['chap2'])


newbook = {"chap6":60,"chap7":70}
finalbook = {**book,**newbook}
print(finalbook)

book.update(newbook)
print(book)
####################################
# display keys
for key in book.keys():
    print(key)

# display values
for value in book.values():
    print(value)
    
# display items
for key,value in book.items():
    print(key,value)
    




print(type(book))
print(isinstance(book,dict))  # True
print(isinstance(book,list))  # False
print(isinstance(book,tuple)) # False

val = 10
print(type(val))
print(isinstance(val,int))
print(isinstance(val,list))







