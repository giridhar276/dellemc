
try:    
    with open('adult1111.csv') as fr,open('adultsUSA.csv','w') as fw:
        for line in fr:
            line = line.strip()
            output = line.replace('United-States','USA')
            fw.write(output + "\n")

except FileNotFoundError as e:
    print(e)
except TypeError as error:
    print(error)
except (IndexError,KeyError) as err:
    print(err)
except Exception as err:     # default exception # baseclass exception
    print(err)